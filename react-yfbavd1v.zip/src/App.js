import React, { useState, useEffect } from "react";
import { MapPin, Plus, Navigation, User, AlertTriangle, ArrowLeft, Trash2, RefreshCw, Camera, Video, Layers, ChevronRight, Trophy } from "lucide-react";
import { createClient } from "@supabase/supabase-js";

// ==========================================
// SUPABASE CONFIGURATION (Free Tier)
// ==========================================
const SUPABASE_URL = "https://bkovtqcdyeknhaslccbr.supabase.co"; 
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJrb3Z0cWNkeWVrbmhhc2xjY2JyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMyMTgwMjQsImV4cCI6MjEwODc5NDAyNH0.fu2HHM22LU2FsmGQkZptEq484MLR3oEHr2iXcNMvFTM"; 
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const UNR_BUILDINGS = [
  "Ansari Business Building", "Church Fine Arts", "Clark Hall", "Davidson Mathematics and Science Center",
  "Edmund J. Cain Hall", "Fitzgerald Student Services Building", "Fleischmann Agriculture",
  "Joe Crowley Student Union (JCSU)", "Jot Travis Building", "Lawlor Events Center", "Leifson Physics",
  "Lombardi Recreation Center", "Mackay Mines", "Mackay Science", "Mathewson-IGT Knowledge Center (MIKC)",
  "National Judicial College", "Palmer Engineering", "Paul MacLean Observatory", "Pennington Medical Education",
  "Pennington Student Achievement Center (PSAC)", "Reynolds School of Journalism", "Ross Hall",
  "Schulich Lecture Hall", "Scrugham Engineering", "Thompson Building", "Virginia Street Gym",
  "William J. Raggio", "Other / Retaining Wall"
];

// Helper to compress images before uploading to Supabase Storage
const compressImage = (file, maxWidth = 900, quality = 0.7) => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        let width = img.width;
        let height = img.height;
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob((blob) => {
          resolve(blob);
        }, "image/jpeg", quality);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
};

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passcode, setPasscode] = useState("");
  const [view, setView] = useState("dashboard"); 
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  
  // Form states
  const [routeName, setRouteName] = useState("");
  const [building, setBuilding] = useState(UNR_BUILDINGS[0]);
  const [grade, setGrade] = useState("V0");
  const [fa, setFa] = useState("");
  const [landing, setLanding] = useState("Good");
  const [description, setDescription] = useState("");
  const [photoFiles, setPhotoFiles] = useState([]);
  const [videoFile, setVideoFile] = useState(null);

  const fetchRoutes = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from("guidebook_routes").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      if (data) {
        const formatted = data.map(item => ({
          id: item.id,
          name: item.name,
          building: item.building,
          grade: item.grade,
          fa: item.fa,
          landing: item.landing,
          description: item.description,
          photos: item.photos || [],
          videoFile: item.video_file || null,
          date: item.date
        }));
        setRoutes(formatted);
        localStorage.setItem("unr_guidebook_backup", JSON.stringify(formatted));
      }
    } catch (err) {
      console.warn("Cloud fetch failed, loading local backup...", err);
      const cached = localStorage.getItem("unr_guidebook_backup");
      if (cached) setRoutes(JSON.parse(cached));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchRoutes();
  }, []);

  // Upload file directly to Supabase Storage bucket and return public URL
  const uploadToStorage = async (file, folder) => {
    const fileName = `${folder}/${Date.now()}_${file.name || "media"}`;
    const { data, error } = await supabase.storage.from("guidebook-media").upload(fileName, file);
    if (error) {
      console.error("Storage upload error:", error);
      throw error;
    }
    const { data: publicUrlData } = supabase.storage.from("guidebook-media").getPublicUrl(data.path);
    return publicUrlData.publicUrl;
  };

  const handleLogin = (e) => {
    e.preventDefault();
    if (passcode.toLowerCase() === "climbon") {
      setIsAuthenticated(true);
      fetchRoutes();
    } else {
      alert("Incorrect access code.");
      setPasscode("");
    }
  };

  const handleAddRoute = async (e) => {
    e.preventDefault();
    setUploading(true);

    try {
      // 1. Upload photos to Supabase Storage
      const uploadedPhotoUrls = [];
      for (let file of photoFiles) {
        const compressedBlob = await compressImage(file);
        const publicUrl = await uploadToStorage(compressedBlob, "photos");
        uploadedPhotoUrls.push(publicUrl);
      }

      // 2. Upload video to Supabase Storage (if provided)
      let uploadedVideoUrl = null;
      if (videoFile) {
        uploadedVideoUrl = await uploadToStorage(videoFile, "videos");
      }

      const newRoute = {
        id: Date.now(),
        name: routeName,
        building,
        grade,
        fa: fa || "Unknown",
        landing,
        description,
        photos: uploadedPhotoUrls,
        videoFile: uploadedVideoUrl,
        date: new Date().toLocaleDateString(),
      };

      // 3. Save metadata to Supabase database table
      const { error } = await supabase.from("guidebook_routes").insert([{
        id: newRoute.id,
        name: newRoute.name,
        building: newRoute.building,
        grade: newRoute.grade,
        fa: newRoute.fa,
        landing: newRoute.landing,
        description: newRoute.description,
        photos: newRoute.photos,
        video_file: newRoute.videoFile,
        date: newRoute.date
      }]);
      if (error) throw error;

      const updated = [newRoute, ...routes];
      setRoutes(updated);
      localStorage.setItem("unr_guidebook_backup", JSON.stringify(updated));

      // Reset form fields
      setRouteName("");
      setBuilding(UNR_BUILDINGS[0]);
      setGrade("V0");
      setFa("");
      setLanding("Good");
      setDescription("");
      setPhotoFiles([]);
      setVideoFile(null);

      // Jump instantly back to homepage dashboard
      setView("dashboard");
    } catch (err) {
      console.error("Save error:", err);
      alert("Failed to save and upload media to cloud. Check your Supabase storage bucket policies.");
    }
    setUploading(false);
  };

  const handleContributeVideo = async (e) => {
    const file = e.target.files[0];
    if (file && selectedRoute) {
      setUploading(true);
      try {
        const uploadedVideoUrl = await uploadToStorage(file, "videos");
        
        const updatedRoutes = routes.map(r => {
          if (r.id === selectedRoute.id) {
            const updatedRouteItem = { ...r, videoFile: uploadedVideoUrl };
            setSelectedRoute(updatedRouteItem);
            return updatedRouteItem;
          }
          return r;
        });
        
        setRoutes(updatedRoutes);
        localStorage.setItem("unr_guidebook_backup", JSON.stringify(updatedRoutes));

        await supabase.from("guidebook_routes").update({
          video_file: uploadedVideoUrl
        }).eq("id", selectedRoute.id);

        alert("Beta video uploaded and synced across devices!");
      } catch (err) {
        console.error("Video contribute error:", err);
        alert("Failed to upload video.");
      }
      setUploading(false);
    }
  };

  const handleDeleteRoute = async (id, e) => {
    if (e) e.stopPropagation();
    if (window.confirm("Are you sure you want to delete this problem?")) {
      const updated = routes.filter(route => route.id !== id);
      setRoutes(updated);
      localStorage.setItem("unr_guidebook_backup", JSON.stringify(updated));
      await supabase.from("guidebook_routes").delete().eq("id", id);
      if (view === "detail") setView("dashboard");
    }
  };

  const groupedRoutes = routes.reduce((acc, route) => {
    const zone = route.building || "Other / Retaining Wall";
    if (!acc[zone]) acc[zone] = [];
    acc[zone].push(route);
    return acc;
  }, {});

  const leaderboardStats = routes.reduce((acc, route) => {
    const climber = route.fa && route.fa.trim() !== "" ? route.fa : "Unknown";
    if (!acc[climber]) {
      acc[climber] = { count: 0, problems: [] };
    }
    acc[climber].count += 1;
    acc[climber].problems.push({ name: route.name, grade: route.grade, date: route.date, building: route.building });
    return acc;
  }, {});

  const sortedLeaderboard = Object.entries(leaderboardStats).sort((a, b) => b[1].count - a[1].count);

  const bgStyle = { backgroundColor: "#f9fafb", color: "#1f2937", minHeight: "100vh", fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" };
  const cardStyle = { backgroundColor: "#ffffff", padding: "16px", borderRadius: "12px", marginBottom: "16px", boxShadow: "0 2px 8px rgba(0,0,0,0.05)", border: "1px solid #e5e7eb", cursor: "pointer", transition: "transform 0.1s ease" };
  const inputStyle = { width: "100%", padding: "12px", marginBottom: "16px", backgroundColor: "#f3f4f6", border: "1px solid #d1d5db", color: "#1f2937", borderRadius: "8px", boxSizing: "border-box", fontSize: "15px" };
  const buttonStyle = { width: "100%", padding: "14px", backgroundColor: "#2e7d32", color: "white", border: "none", borderRadius: "8px", fontWeight: "600", fontSize: "16px", cursor: "pointer", boxShadow: "0 4px 6px rgba(46, 125, 50, 0.2)" };

  if (!isAuthenticated) {
    return (
      <div style={{ ...bgStyle, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "20px" }}>
        <div style={{ backgroundColor: "white", padding: "40px 24px", borderRadius: "16px", boxShadow: "0 4px 12px rgba(0,0,0,0.05)", width: "100%", maxWidth: "320px", textAlign: "center", border: "1px solid #e5e7eb" }}>
          <Navigation size={48} color="#2e7d32" style={{ marginBottom: "16px" }} />
          <h1 style={{ margin: "0 0 8px 0", color: "#111827", fontSize: "24px", fontWeight: "700" }}>Campus Guide</h1>
          <p style={{ color: "#6b7280", margin: "0 0 24px 0", fontSize: "14px" }}>Enter passcode to view beta.</p>
          <form onSubmit={handleLogin}>
            <input type="password" placeholder="Passcode" value={passcode} onChange={(e) => setPasscode(e.target.value)} style={{ ...inputStyle, textAlign: "center", letterSpacing: "2px", fontSize: "16px", backgroundColor: "white" }} />
            <button type="submit" style={buttonStyle}>Access Guidebook</button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div style={{ ...bgStyle, padding: "20px", maxWidth: "600px", margin: "0 auto" }}>
      
      {view !== "add" && view !== "detail" && (
        <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
          <button 
            onClick={() => setView("dashboard")} 
            style={{ flex: 1, padding: "10px", borderRadius: "8px", border: "none", fontWeight: "700", cursor: "pointer", backgroundColor: view === "dashboard" ? "#2e7d32" : "#e5e7eb", color: view === "dashboard" ? "white" : "#4b5563" }}
          >
            📖 Guidebook
          </button>
          <button 
            onClick={() => setView("leaderboard")} 
            style={{ flex: 1, padding: "10px", borderRadius: "8px", border: "none", fontWeight: "700", cursor: "pointer", backgroundColor: view === "leaderboard" ? "#2e7d32" : "#e5e7eb", color: view === "leaderboard" ? "white" : "#4b5563", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }}
          >
            <Trophy size={16} /> Ascents
          </button>
        </div>
      )}

      {/* ================= DASHBOARD VIEW ================= */}
      {view === "dashboard" && (
        <>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px", paddingBottom: "16px", borderBottom: "2px solid #e5e7eb" }}>
            <div>
              <h2 style={{ margin: 0, color: "#111827", fontSize: "24px", fontWeight: "800" }}>UNR Bouldering</h2>
              <p style={{ margin: "4px 0 0 0", color: "#6b7280", fontSize: "14px", fontWeight: "500" }}>{routes.length} problems mapped across {Object.keys(groupedRoutes).length} zones</p>
            </div>
            <div style={{ display: "flex", gap: "8px" }}>
              <button onClick={fetchRoutes} style={{ backgroundColor: "#f3f4f6", border: "1px solid #d1d5db", borderRadius: "50%", width: "44px", height: "44px", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }} title="Sync / Refresh">
                <RefreshCw color="#4b5563" size={20} className={loading ? "animate-spin" : ""} />
              </button>
              <button onClick={() => setView("add")} style={{ backgroundColor: "#2e7d32", border: "none", borderRadius: "50%", width: "44px", height: "44px", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", boxShadow: "0 2px 4px rgba(46, 125, 50, 0.3)" }}>
                <Plus color="white" size={24} />
              </button>
            </div>
          </div>

          {routes.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: "#9ca3af" }}>
              <MapPin size={48} style={{ margin: "0 auto 16px", opacity: 0.3 }} />
              <h3 style={{ margin: "0 0 8px 0", color: "#4b5563" }}>No Ascents Logged</h3>
              <p style={{ margin: 0, fontSize: "14px" }}>Tap the plus icon to add the first problem.</p>
            </div>
          ) : (
            Object.entries(groupedRoutes).map(([zoneName, zoneRoutes]) => (
              <div key={zoneName} style={{ marginBottom: "28px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "12px", borderBottom: "2px solid #d1d5db", paddingBottom: "6px" }}>
                  <Layers size={18} color="#2e7d32" />
                  <h3 style={{ margin: 0, fontSize: "16px", fontWeight: "700", color: "#111827" }}>{zoneName}</h3>
                  <span style={{ fontSize: "12px", backgroundColor: "#e5e7eb", color: "#4b5563", padding: "2px 8px", borderRadius: "10px", fontWeight: "600" }}>{zoneRoutes.length}</span>
                </div>

                {zoneRoutes.map((route) => (
                  <div 
                    key={route.id} 
                    style={cardStyle}
                    onClick={() => { setSelectedRoute(route); setView("detail"); }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "12px" }}>
                      <div>
                        <h4 style={{ margin: "0 0 4px 0", color: "#111827", fontSize: "18px", fontWeight: "700", display: "flex", alignItems: "center", gap: "6px" }}>
                          {route.name} <ChevronRight size={16} color="#9ca3af" />
                        </h4>
                        <div style={{ display: "flex", alignItems: "center", color: "#4b5563", fontSize: "13px", fontWeight: "500" }}>
                          <MapPin size={14} style={{ marginRight: "4px" }} /> {route.building}
                        </div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                        <span style={{ backgroundColor: "#111827", padding: "4px 10px", borderRadius: "6px", fontSize: "15px", fontWeight: "800", color: "white" }}>{route.grade}</span>
                        <button 
                          onClick={(e) => handleDeleteRoute(route.id, e)} 
                          style={{ background: "none", border: "none", cursor: "pointer", color: "#9ca3af", padding: "4px", display: "flex", alignItems: "center" }}
                          title="Delete Problem"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>

                    {route.photos && route.photos.length > 0 && (
                      <div style={{ marginBottom: "12px", borderRadius: "8px", overflow: "hidden", border: "1px solid #e5e7eb" }}>
                        <img src={route.photos[0]} alt={route.name} style={{ width: "100%", maxHeight: "200px", objectFit: "cover", display: "block" }} />
                      </div>
                    )}

                    <div style={{ display: "flex", gap: "16px", fontSize: "13px", color: "#6b7280" }}>
                      <span>FA: {route.fa}</span>
                      <span>Landing: {route.landing}</span>
                      {route.photos?.length > 1 && <span>📷 {route.photos.length} photos</span>}
                      {route.videoFile && <span>🎥 Video beta</span>}
                    </div>
                  </div>
                ))}
              </div>
            ))
          )}
        </>
      )}

      {/* ================= ASCENTS VIEW ================= */}
      {view === "leaderboard" && (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "20px" }}>
            <Trophy size={28} color="#2e7d32" />
            <div>
              <h2 style={{ margin: 0, color: "#111827", fontSize: "22px", fontWeight: "800" }}>Ascents Leaderboard</h2>
              <p style={{ margin: "2px 0 0 0", color: "#6b7280", fontSize: "13px" }}>First Ascents and problems synced across devices</p>
            </div>
          </div>

          {sortedLeaderboard.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: "#9ca3af" }}>
              <Trophy size={48} style={{ margin: "0 auto 16px", opacity: 0.3 }} />
              <h3 style={{ margin: "0 0 8px 0", color: "#4b5563" }}>No Ascents Logged Yet</h3>
              <p style={{ margin: 0, fontSize: "14px" }}>Log problems with an FA name to populate scores.</p>
            </div>
          ) : (
            sortedLeaderboard.map(([climber, data], index) => (
              <div key={climber} style={{ backgroundColor: "white", padding: "16px", borderRadius: "12px", marginBottom: "16px", border: "1px solid #e5e7eb", boxShadow: "0 2px 6px rgba(0,0,0,0.04)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px", borderBottom: "1px solid #f3f4f6", paddingBottom: "10px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                    <span style={{ backgroundColor: index === 0 ? "#f59e0b" : index === 1 ? "#94a3b8" : index === 2 ? "#b45309" : "#e5e7eb", color: "white", width: "26px", height: "26px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "13px", fontWeight: "800" }}>
                      {index + 1}
                    </span>
                    <h3 style={{ margin: 0, fontSize: "17px", fontWeight: "700", color: "#111827" }}>{climber}</h3>
                  </div>
                  <span style={{ fontSize: "13px", fontWeight: "700", backgroundColor: "#ecfdf5", color: "#059669", padding: "4px 10px", borderRadius: "12px" }}>
                    {data.count} {data.count === 1 ? "Ascent" : "Ascents"}
                  </span>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  {data.problems.map((prob, i) => (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: "13px", backgroundColor: "#f9fafb", padding: "8px 12px", borderRadius: "6px" }}>
                      <div>
                        <span style={{ fontWeight: "700", color: "#1f2937" }}>{prob.name}</span>
                        <span style={{ color: "#6b7280", marginLeft: "6px" }}>({prob.building})</span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <span style={{ backgroundColor: "#111827", color: "white", padding: "2px 6px", borderRadius: "4px", fontWeight: "700", fontSize: "11px" }}>{prob.grade}</span>
                        <span style={{ color: "#9ca3af", fontSize: "12px" }}>{prob.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </>
      )}

      {/* ================= ROUTE DETAIL VIEW ================= */}
      {view === "detail" && selectedRoute && (
        <>
          <button onClick={() => setView("dashboard")} style={{ background: "none", border: "none", color: "#4b5563", display: "flex", alignItems: "center", padding: 0, cursor: "pointer", marginBottom: "20px", fontWeight: "600" }}>
            <ArrowLeft size={20} style={{ marginRight: "4px" }} /> Back to Guidebook
          </button>

          <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "12px", border: "1px solid #e5e7eb", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "16px" }}>
              <div>
                <h2 style={{ margin: "0 0 6px 0", fontSize: "24px", fontWeight: "800", color: "#111827" }}>{selectedRoute.name}</h2>
                <div style={{ display: "flex", alignItems: "center", color: "#4b5563", fontSize: "14px", fontWeight: "500" }}>
                  <MapPin size={16} style={{ marginRight: "4px" }} /> {selectedRoute.building}
                </div>
              </div>
              <span style={{ backgroundColor: "#111827", padding: "6px 12px", borderRadius: "8px", fontSize: "18px", fontWeight: "800", color: "white" }}>{selectedRoute.grade}</span>
            </div>

            <div style={{ display: "flex", gap: "16px", marginBottom: "20px", paddingBottom: "16px", borderBottom: "1px solid #f3f4f6" }}>
              <div style={{ display: "flex", alignItems: "center", color: "#6b7280", fontSize: "13px" }}>
                <User size={14} style={{ marginRight: "4px" }} /> FA: {selectedRoute.fa}
              </div>
              <div style={{ display: "flex", alignItems: "center", color: selectedRoute.landing === "Good" ? "#059669" : selectedRoute.landing === "Uneven" ? "#d97706" : "#dc2626", fontSize: "13px", fontWeight: "500" }}>
                <AlertTriangle size={14} style={{ marginRight: "4px" }} /> Landing: {selectedRoute.landing}
              </div>
            </div>

            <h3 style={{ fontSize: "13px", textTransform: "uppercase", letterSpacing: "1px", color: "#9ca3af", marginBottom: "8px" }}>Beta & Description</h3>
            <p style={{ margin: "0 0 24px 0", lineHeight: "1.6", color: "#374151", fontSize: "15px" }}>{selectedRoute.description}</p>

            {/* Video Beta Section */}
            <div style={{ marginBottom: "24px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                <h3 style={{ fontSize: "13px", textTransform: "uppercase", letterSpacing: "1px", color: "#9ca3af", margin: 0 }}>Beta Video</h3>
                <label style={{ fontSize: "13px", color: "#2e7d32", fontWeight: "700", cursor: "pointer", display: "flex", alignItems: "center", gap: "4px", backgroundColor: "#ecfdf5", padding: "6px 10px", borderRadius: "6px" }}>
                  <Video size={14} /> {uploading ? "Uploading..." : "Add Beta Clip"}
                  <input type="file" accept="video/*" onChange={handleContributeVideo} disabled={uploading} style={{ display: "none" }} />
                </label>
              </div>

              {selectedRoute.videoFile ? (
                <div style={{ borderRadius: "8px", overflow: "hidden", background: "#000", border: "1px solid #e5e7eb" }}>
                  <video controls style={{ width: "100%", maxHeight: "350px", display: "block" }} src={selectedRoute.videoFile}>
                    Your browser does not support native video playback.
                  </video>
                </div>
              ) : (
                <p style={{ fontSize: "13px", color: "#9ca3af", fontStyle: "italic", margin: 0 }}>No beta video uploaded yet. Click above to add one!</p>
              )}
            </div>

            {/* Photo Gallery */}
            {selectedRoute.photos && selectedRoute.photos.length > 0 && (
              <div style={{ marginBottom: "24px" }}>
                <h3 style={{ fontSize: "13px", textTransform: "uppercase", letterSpacing: "1px", color: "#9ca3af", marginBottom: "12px" }}>Photo Gallery ({selectedRoute.photos.length})</h3>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                  {selectedRoute.photos.map((p, idx) => (
                    <div key={idx} style={{ borderRadius: "8px", overflow: "hidden", border: "1px solid #e5e7eb" }}>
                      <img src={p} alt={`Beta ${idx + 1}`} style={{ width: "100%", height: "140px", objectFit: "cover", display: "block" }} />
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button 
              onClick={(e) => handleDeleteRoute(selectedRoute.id, e)} 
              style={{ width: "100%", padding: "12px", backgroundColor: "#fee2e2", color: "#dc2626", border: "none", borderRadius: "8px", fontWeight: "600", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}
            >
              <Trash2 size={16} /> Delete This Problem
            </button>
          </div>
        </>
      )}

      {/* ================= ADD ROUTE VIEW ================= */}
      {view === "add" && (
        <>
          <button onClick={() => setView("dashboard")} style={{ background: "none", border: "none", color: "#4b5563", display: "flex", alignItems: "center", padding: 0, cursor: "pointer", marginBottom: "24px", fontWeight: "600" }}>
            <ArrowLeft size={20} style={{ marginRight: "4px" }} /> Cancel
          </button>
          <h2 style={{ marginTop: 0, color: "#111827", marginBottom: "20px", fontSize: "22px" }}>Log a New Problem</h2>
          <form onSubmit={handleAddRoute}>
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>Route Name</label>
            <input required type="text" value={routeName} onChange={(e) => setRouteName(e.target.value)} placeholder="e.g. The Palmer Pinch" style={inputStyle} />
            <div style={{ display: "flex", gap: "12px" }}>
              <div style={{ flex: 1 }}>
                <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>Grade</label>
                <input required type="text" value={grade} onChange={(e) => setGrade(e.target.value)} placeholder="V0" style={inputStyle} />
              </div>
              <div style={{ flex: 1 }}>
                <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>First Ascent (FA)</label>
                <input type="text" value={fa} onChange={(e) => setFa(e.target.value)} placeholder="Name or Unknown" style={inputStyle} />
              </div>
            </div>
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>Building / Zone Chapter</label>
            <select value={building} onChange={(e) => setBuilding(e.target.value)} style={inputStyle}>
              {UNR_BUILDINGS.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>Landing Quality</label>
            <select value={landing} onChange={(e) => setLanding(e.target.value)} style={inputStyle}>
              <option value="Good">Good (Flat, easy pad placement)</option>
              <option value="Uneven">Uneven (Curbs, steps, requires multiple pads)</option>
              <option value="Sketchy">Sketchy (Obstacles, bad fall zone)</option>
            </select>
            
            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>Photos (Upload multiple)</label>
            <div style={{ ...inputStyle, display: "flex", alignItems: "center", gap: "12px", background: "white" }}>
              <Camera size={20} color="#4b5563" />
              <input type="file" multiple accept="image/*" onChange={(e) => setPhotoFiles(Array.from(e.target.files))} style={{ fontSize: "14px", width: "100%" }} />
            </div>

            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>Beta Video (Direct Upload)</label>
            <div style={{ ...inputStyle, display: "flex", alignItems: "center", gap: "12px", background: "white" }}>
              <Video size={20} color="#4b5563" />
              <input type="file" accept="video/*" onChange={(e) => setVideoFile(e.target.files[0])} style={{ fontSize: "14px", width: "100%" }} />
            </div>

            <label style={{ display: "block", marginBottom: "6px", fontSize: "13px", fontWeight: "600", color: "#4b5563" }}>Beta & Description</label>
            <textarea required rows="4" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe the start holds, crux, and top out..." style={{ ...inputStyle, resize: "vertical" }} />
            
            <button type="submit" disabled={uploading} style={{ ...buttonStyle, marginTop: "8px", opacity: uploading ? 0.7 : 1 }}>
              {uploading ? "Uploading media & saving..." : "Save to Guidebook"}
            </button>
          </form>
        </>
      )}

    </div>
  );
}